package com.ns.contactPack.contactPack;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Contact")
public class    ContactDetails {

    @Id
    private Integer sNo;

    @Column(name="PersonName")
    private String personName;

    @Column(name="EMail")
    private String personEmail;

    @Column(name="PhoneNumber")
    private String personPhone;

    public ContactDetails() {
    }

    public Integer getsNo() {
        return sNo;
    }

    public void setsNo(Integer sNo) {
        this.sNo = sNo;
    }

    public ContactDetails(Integer sNo, String personName, String personEmail, String personPhone) {
        this.sNo = sNo;
        this.personName = personName;
        this.personEmail = personEmail;
        this.personPhone = personPhone;

    }

    public String getPersonName() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }

    public String getPersonEmail() {
        return personEmail;
    }

    public void setPersonEmail(String personEmail) {
        this.personEmail = personEmail;
    }

    public String getPersonPhone() {
        return personPhone;
    }

    public void setPersonPhone(String personPhone) {
        this.personPhone = personPhone;
    }
}
